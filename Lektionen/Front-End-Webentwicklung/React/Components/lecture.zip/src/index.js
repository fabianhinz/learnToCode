import React from 'react';
import {render} from 'react-dom'

const Component = () => (
    <div>tausch mich aus</div>
)

render(<Component />, document.getElementById('root'));
